package com.monolithic.service;

import java.util.List;
import com.monolithic.model.Branch;

public interface BranchService {
    List<Branch> getAllBranches();
    Branch addBranch(Branch branch);
    Branch getBranchById(Long id);
    Branch updateBranch(Long id, Branch branch);
    void deleteBranch(Long id);
}
