package com.monolithic.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.monolithic.model.Branch;
import com.monolithic.repository.BranchRepository;

@Service
public class BranchServiceImpl implements BranchService {
	@Autowired
	public BranchRepository brepo;

	@Override
	public List<Branch> getAllBranches() {
		 return brepo.findAll();
	}

	@Override
	public Branch addBranch(Branch branch) {
		return brepo.save(branch);
	}
	@Override
    public Branch getBranchById(Long id) {
        return brepo.findById(id).orElse(null);
    }

    @Override
    public Branch updateBranch(Long id, Branch updatedBranch) {
        Optional<Branch> optionalBranch = brepo.findById(id);
        if (optionalBranch.isPresent()) {
            Branch branch = optionalBranch.get();
            branch.setBran_name(updatedBranch.getBran_name());
            branch.setHod_name(updatedBranch.getHod_name());
            return brepo.save(branch);
        }
        return null;
    }

    @Override
    public void deleteBranch(Long id) {
        brepo.deleteById(id);
    }

	

}
