package com.monolithic.service;

import java.util.List;

import com.monolithic.model.College;

public interface CollegeService {
	
	List<College> getCollegeDetails();
	
	College addCollege(College college);
	College getCollegeById(Long id);

    College updateCollege(Long id, College updatedCollege);

    void deleteCollege(Long id);
}
