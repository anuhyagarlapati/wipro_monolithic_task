package com.monolithic.service;

import java.util.List;
import java.util.Optional;

import com.monolithic.model.Student;

public interface StudentService {
	
	 List<Student> getAllStudents();
	 Student addStudent(Student student);
	 Optional<Student> getStudentWithDetails(long id);
	 Student updateStudent(long id, Student student);
	 void deleteStudent(long id);
	 
	

}
