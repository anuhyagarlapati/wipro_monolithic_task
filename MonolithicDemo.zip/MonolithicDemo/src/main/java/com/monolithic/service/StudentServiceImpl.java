package com.monolithic.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.monolithic.model.Branch;
import com.monolithic.model.College;
import com.monolithic.model.Student;
import com.monolithic.repository.BranchRepository;
import com.monolithic.repository.CollegeRepository;
import com.monolithic.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepository srepo;

    @Autowired
    private CollegeRepository crepo;

    @Autowired
    private BranchRepository brepo;

    @Override
    public List<Student> getAllStudents() {
    	List<Student> students = srepo.findAll();

        for (Student student : students) {
            College college = crepo.findById(student.getClg_id()).orElse(null);
            Branch branch = brepo.findById(student.getBranch_id()).orElse(null);

            student.setCollege(college);
            student.setBranch(branch);
        }

        return students;
    }

    @Override
    public Optional<Student> getStudentWithDetails(long stuId) {
        Optional<Student> studentOpt = srepo.findById(stuId);
        if(studentOpt.isEmpty()) {
            return Optional.empty();
        }
        Student student = studentOpt.get();

        College college = crepo.findById(student.getClg_id()).orElse(null);
        Branch branch = brepo.findById(student.getBranch_id()).orElse(null);

        student.setCollege(college);
        student.setBranch(branch);

        return Optional.of(student);
    }


    @Override
    public Student addStudent(Student student) {
        return srepo.save(student);
    }
    @Override
    public Student updateStudent(long id, Student updatedStudent) {
        Optional<Student> studentOpt = srepo.findById(id);
        if (studentOpt.isPresent()) {
            Student student = studentOpt.get();
            student.setName(updatedStudent.getName());
            student.setRoll_no(updatedStudent.getRoll_no());
            student.setPhoneno(updatedStudent.getPhoneno());
            student.setClg_id(updatedStudent.getClg_id());
            student.setBranch_id(updatedStudent.getBranch_id());
            return srepo.save(student);
        }
        return null;
    }

    @Override
    public void deleteStudent(long id) {
    	srepo.deleteById(id);
    }
      
}
