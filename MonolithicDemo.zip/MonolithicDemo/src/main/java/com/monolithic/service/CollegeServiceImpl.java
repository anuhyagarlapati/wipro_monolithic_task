package com.monolithic.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.monolithic.model.College;
import com.monolithic.repository.CollegeRepository;

@Service
public class CollegeServiceImpl implements CollegeService {
	@Autowired
	public CollegeRepository crepo;

	@Override
	public List<College> getCollegeDetails() {
		return crepo.findAll();
		
	}

	@Override
	public College addCollege(College college) {
		return crepo.save(college);
	}
	@Override
    public College getCollegeById(Long id) {
        return crepo.findById(id).orElse(null);
    }

    @Override
    public College updateCollege(Long id, College updatedCollege) {
        Optional<College> optionalCollege = crepo.findById(id);
        if (optionalCollege.isPresent()) {
            College college = optionalCollege.get();
            college.setName(updatedCollege.getName());
            college.setLocation(updatedCollege.getLocation());
            return crepo.save(college);
        }
        return null;
    }

    @Override
    public void deleteCollege(Long id) {
    	crepo.deleteById(id);
    }

}
