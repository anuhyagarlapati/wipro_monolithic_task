package com.monolithic.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.monolithic.model.College;
import com.monolithic.service.CollegeService;

@RestController
@RequestMapping("/college")

public class CollegeController {
	@Autowired
	public CollegeService clgservice;
	
	@GetMapping("/get")
	public List<College> getCollegeDetails(){
		return clgservice.getCollegeDetails();
	}
	
	@PostMapping("/add")
	public College addCollege(@RequestBody College college) {
		return clgservice.addCollege(college);
	}
	@GetMapping("/{id}")
    public College getCollegeById(@PathVariable Long id) {
        return clgservice.getCollegeById(id);
    }

    @PutMapping("/{id}")
    public College updateCollege(@PathVariable Long id, @RequestBody College updatedCollege) {
        return clgservice.updateCollege(id, updatedCollege);
    }

    @DeleteMapping("/{id}")
    public String deleteCollege(@PathVariable Long id) {
    	clgservice.deleteCollege(id);
        return "College with ID " + id + " deleted successfully.";
    }

}
