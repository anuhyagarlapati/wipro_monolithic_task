package com.monolithic.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.monolithic.model.College;

public interface CollegeRepository extends JpaRepository<College,Long> {

}
