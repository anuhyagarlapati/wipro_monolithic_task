package com.monolithic.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Branch {
	@Id
	@GeneratedValue
	private long bran_id;
	private String bran_name;
	private String Hod_name;
	
	public Branch(String bran_name,String Hod_name) {
		super();
		this.bran_name=bran_name;
		this.Hod_name=Hod_name;
	}
	public Branch() {
		super();
	}
	public long getBran_id() {
		return bran_id;
	}

	public void setBran_id(long bran_id) {
		this.bran_id = bran_id;
	}

	public String getBran_name() {
		return bran_name;
	}

	public void setBran_name(String bran_name) {
		this.bran_name = bran_name;
	}

	public String getHod_name() {
		return Hod_name;
	}

	public void setHod_name(String hod_name) {
		Hod_name = hod_name;
	}

}
