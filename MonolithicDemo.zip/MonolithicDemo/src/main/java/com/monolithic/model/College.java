package com.monolithic.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class College {
	@Id
	@GeneratedValue
	private long id;
	private String name;
	private String location;
	
	public College(String name,String location) {
		super();
		this.name=name;
		this.location=location;
		
	}
	public College() {
		
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	
	

}
