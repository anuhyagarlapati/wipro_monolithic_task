package com.monolithic.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;

@Entity
public class Student {

    @Id
    @GeneratedValue
    private long Stu_id;

    private String name;
    private String roll_no;
    private long phoneno;

    @Column(name = "clg_id")
    private long clg_id;

    @Column(name = "branch_id")
    private long branch_id;

    @Transient
    private College college;

    @Transient
    private Branch branch;
    public Student() {}

    public Student(String name, String roll_no, long phoneno, long clg_id, long branch_id) {
        this.name = name;
        this.roll_no = roll_no;
        this.phoneno = phoneno;
        this.clg_id = clg_id;
        this.branch_id = branch_id;
    }

  

    public long getStu_id() {
        return Stu_id;
    }

    public void setStu_id(long stu_id) {
        Stu_id = stu_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRoll_no() {
        return roll_no;
    }

    public void setRoll_no(String roll_no) {
        this.roll_no = roll_no;
    }

    public long getPhoneno() {
        return phoneno;
    }

    public void setPhoneno(long phoneno) {
        this.phoneno = phoneno;
    }

    public long getClg_id() {
        return clg_id;
    }

    public void setClg_id(long clg_id) {
        this.clg_id = clg_id;
    }

    public long getBranch_id() {
        return branch_id;
    }

    public void setBranch_id(long branch_id) {
        this.branch_id = branch_id;
    }

    public College getCollege() {
        return college;
    }

    public void setCollege(College college) {
        this.college = college;
    }

    public Branch getBranch() {
        return branch;
    }

    public void setBranch(Branch branch) {
        this.branch = branch;
    }
}
