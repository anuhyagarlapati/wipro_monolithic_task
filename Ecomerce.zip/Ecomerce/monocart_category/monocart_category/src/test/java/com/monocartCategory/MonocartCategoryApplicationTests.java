package com.monocartCategory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonocartCategoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
